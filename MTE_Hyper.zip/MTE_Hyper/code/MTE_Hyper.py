"""
1. Create Multi-table hyper file from hyper datasource
2. To publish multi table hyper file, create the relationships(tableau version 2020 reqd) for stand-alone tables
   and publish it to the server manually(one-time manual step).
3. Download the published datasource as a tdsx file.
4. Replace tdsx with hyper and overwrite the file through the script.
5. Publish the new file to the server through the script.

"""

#Python packages

from pathlib import Path
from tableauhyperapi import HyperProcess, Telemetry, \
Connection, CreateMode, \
NOT_NULLABLE, NULLABLE, SqlType, TableDefinition, \
Inserter, \
escape_name, escape_string_literal, \
HyperException, TableName, Timestamp
from tableau_api_lib import TableauServerConnection
from tableau_api_lib.utils.querying import get_projects_dataframe
import psycopg2
import xml.etree.ElementTree as ET
import requests
import os, sys
from tableau_tools.tableau_documents import *
from tableau_tools import *
#####################################
#####################################


#1 a. Getting file name to use it as a table name from template hyper file.

def get_file_name(template):
    path_to_template_database = template
    file_name = Path(path_to_template_database).stem
    return file_name

#####################################
#####################################

#1 b. The template provides the list of columns the output hyper will be having. This can be a sample records in a hyper file

def read_template_hyper(template):
    path_to_template_database = template
    #print(get_file_name(template))
    with HyperProcess(telemetry=Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hyper:
        # Connect to existing Hyper file "superstore_sample_read.hyper".
        with Connection(endpoint=hyper.endpoint,
                        database=path_to_template_database) as connection:
            # The table names in the "public" schema (the default schema).
            schema_name = connection.catalog.get_schema_names()
            #print('Schema Name', schema_name)

            # Choose the schema from the input hyper file in schema=schema_name[].
            table_names = connection.catalog.get_table_names(schema=schema_name[1])
            #print(table_names)
            column_list = []
            for table in table_names:
                table_definition = connection.catalog.get_table_definition(name=table)
                table_names = connection.catalog.get_table_names(schema=schema_name[1])
                data = connection.execute_list_query(query=f"SELECT * FROM {table}")
                return [table_definition, table_names, data]

#1 c. This part will initialize the table creation and Data Ingestion to multiple hyper tables.

def run_insert_data_into_multiple_tables():
    """
    An example of how to create and insert data into a multi-table Hyper file where tables have different types
    """
    print("EXAMPLE - Insert data into multiple tables within a new Hyper file")
    path_to_database = "..//hyper_output.hyper"

    # Starts the Hyper Process with telemetry enabled to send data to Tableau.
    # To opt out, simply set telemetry=Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU.
    with HyperProcess(telemetry=Telemetry.SEND_USAGE_DATA_TO_TABLEAU) as hyper:

        # Creates new Hyper file "superstore.hyper".
        # Replaces file with CreateMode.CREATE_AND_REPLACE if it already exists.
        with Connection(endpoint=hyper.endpoint,
                        database=path_to_database,
                        create_mode=CreateMode.CREATE_AND_REPLACE ) as connection:  #For updating existing file

            # Create multiple tables.

            connection.catalog.create_schema('Extract')
            connection.catalog.create_table(TableDefinition(TableName('Extract', 'People'), People_table_definition[0].columns))
            connection.catalog.create_table(TableDefinition(TableName('Extract', 'Returns'), Returns_table_definition[0].columns))

            for table in People_table_definition[1]:
                with Inserter(connection, TableName('Extract','People')) as inserter:
                    inserter.add_rows(rows = People_table_definition[2])
                    inserter.execute()
            for table in People_table_definition[1]:
                with Inserter(connection, TableName('Extract','Returns')) as inserter:
                    inserter.add_rows(rows = People_table_definition[2])
                    inserter.execute()

            table_names = [ TableName ('Extract','People'), TableName ('Extract','Returns')]
            for table in table_names:
                # `execute_scalar_query` is for executing a query that returns exactly one row with one column.
                row_count = connection.execute_scalar_query(query=f"SELECT COUNT(*) FROM {table}")
                print(f"The number of rows in table {table} is {row_count}.")
        print("The connection to the Hyper file has been closed.")
        with Connection(endpoint=hyper.endpoint,
                        database=path_to_database,
                        create_mode=CreateMode.NONE ) as connection:  #For updating existing file

            # Create increment table which stores history with incremental data.

            connection.catalog.create_table(TableDefinition(TableName('Extract','Orders'),Orders_table_definition[0].columns))
            # Insert data into TPP table.
            for table in Orders_table_definition[1]:
                with Inserter(connection, TableName('Extract','Orders')) as inserter:
                    inserter.add_rows(rows = Orders_table_definition[2])
                    inserter.execute()
            table_names = [ TableName ('Extract','Orders')]
            for table in table_names:
                # `execute_scalar_query` is for executing a query that returns exactly one row with one column.
                row_count = connection.execute_scalar_query(query=f"SELECT COUNT(*) FROM {table}")
                print(f"The number of rows in table {table} is {row_count}.")
        print("The connection to the Hyper file has been closed.")
    print("The Hyper process has been shut down.")

#################################
#Steps #2 and #3 are manual process
#4. Replace existing tdsx file with the hyper file.

def swap_hyper(hyper_name, tdsx_name, logger_obj = None):
    '''Uses tableau_tools to open a local .tdsx file and replace the hyperfile.'''
    # Checks to see if TDSX exists, otherwise, as a one-time step, user will need to create using Desktop.
    path_to_database = hyper_name
    path_to_tdsx_name = tdsx_name
    if os.path.exists(tdsx_name):
        print("Found TDSX file.")
    else:
        message = "--Could not find existing TDSX file. Please use Desktop to create one from the newly created hyper file or update the config file.--"
        sys.exit(message)
# Uses tableau_tools to replace the hyper file in the TDSX.
    try:
        local_tds = TableauFileManager.open(filename=tdsx_name, logger_obj=logger_obj)
    except TableauException as e:
        print(e)
        sys.exit(e)
    filenames = local_tds.get_filenames_in_package()
    for filename in filenames:
        if filename.find('.hyper') != -1:
            print("Overwriting Hyper in original TDSX")
            local_tds.set_file_for_replacement(filename_in_package=filename,replacement_filname_on_disk=hyper_name)
            break

    # Overwrites the original TDSX file locally.
    tdsx_name_before_extension, tdsx_name_extension = os.path.splitext(tdsx_name)
    tdsx_updated_name = tdsx_name_before_extension + '_updated' + tdsx_name_extension
    local_tds.save_new_file(new_filename_no_extension=tdsx_updated_name)
    os.remove(tdsx_name)
    os.rename(tdsx_updated_name, tdsx_name)

#################################

#5. Publish the hyper file
def publish_datasource():
    tableau_server_config = {
        'my_env': {
            'server': SERVER,
            'api_version': '3.9',
            'username': USER,
            'password': PASSWORD,
            'site_name': SITE_NAME,
            'site_url': SITE
        }
    }
    conn = TableauServerConnection(tableau_server_config, env='my_env')
    conn.sign_in()
    projects_df = get_projects_dataframe(conn)
    print(projects_df[['name', 'id']])
    #print(projects_df[['name', 'id']]

    #Publish the datasource without embedding credentials
    response = conn.publish_data_source(datasource_file_path=path_to_tdsx_name,
                                    datasource_name='hyper_output',
                                    project_id='PROJECT_LUID'
    )
    print(response.json())
#################################
xmlns = {'t': 'http://tableau.com/api'}
def sign_in(SERVER, name, password, site):
    url = SERVER + "/api/3.1/auth/signin"
    # Builds the request
    xml_payload_for_request = ET.Element('tsRequest')
    credentials_element = ET.SubElement(xml_payload_for_request,'credentials',name = name, password= password)
    site_element = ET.SubElement(credentials_element, 'site', contentUrl=site)
    xml_payload_for_request = ET.tostring(xml_payload_for_request)
    print(url,xml_payload_for_request)

    #Makes the request to Tableau Server
    SERVER_response = requests.post(url, data=xml_payload_for_request)
    print(SERVER_response)
    if SERVER_response.status_code != 200:
        print(SERVER_response.text)
        sys.exit(1)
    #Reads and parses the response
    xml_response = ET.fromstring(encode_for_display(SERVER_response.text))
    #Gets the TOKEN and Site ID
    TOKEN = xml_response.find('t:credentials', namespaces=xmlns).attrib.get('token')
    site_id = xml_response.find('.//t:site', namespaces=xmlns).attrib.get('id')
    user_id = xml_response.find('.//t:user', namespaces=xmlns).attrib.get('id')
    return TOKEN,site_id,user_id

#################################

def encode_for_display(text):
    return text.encode('ascii', errors = "backslashreplace").decode('utf-8')

#################################

if __name__ == '__main__':
    SERVER = "SERVER_NAME"
    USER = 'USER_NAME'
    PASSWORD = 'PASSWORD'
    CHUNKED = True
    SITE_NAME = 'SITE_NAME'
    SITE = 'SITE_URLNAMESPACE'

    path_to_Orders_template = "..//Orders.hyper"
    path_to_People_template = "..//People.hyper"
    path_to_Returns_template = "..//Returns.hyper"

    Orders_table_definition = read_template_hyper(path_to_Orders_template)
    People_table_definition = read_template_hyper(path_to_People_template)
    Returns_table_definition = read_template_hyper(path_to_Returns_template)

    path_to_database = "..//hyper_output.hyper"
    path_to_tdsx_name = "..//hyper_output.tdsx"

    #print(hour_wise_table_definition)
    try:
        #sign_in(SERVER, name, password, site)
        get_file_name(path_to_Orders_template)
        read_template_hyper(path_to_Orders_template)
        run_insert_data_into_multiple_tables()
        #swap_hyper(path_to_database,path_to_tdsx_name)
        #publish_datasource()
    except HyperException as ex:
        print(ex)
        exit(1)
